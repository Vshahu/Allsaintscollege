<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {

	 public function __construct()
                          {
	parent::__construct();
 
$this->load->helper(array('form','url'));
		$this->load->library(array('session', 'form_validation', 'email'));
		$this->load->database();
		$this->load->model('Authenticate_model');
         
                    }
	public function index()
	
	{ 
	
		$this->load->view('login.php');
	}
	
		/*Start Page Mention Here*/
		
	public function Auth(){
        // Validation Rules
        $this->form_validation->set_rules('username','Username','trim|required|min_length[3]');
        $this->form_validation->set_rules('password','Password','trim|required|min_length[3]');


        if ($this->form_validation->run() == false) {
            // View
            $this->load->view('login.php');
        }else{
            // Get From Post
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            // Validate Username & Password
            $member_id = $this->Authenticate_model->login($username, $password);

            if ($member_id != false) {
                $user_data = array(
                    'user_id' => $member_id, 
                    'username' => $username,
                    'logged_in' => true
                    );

                // Set session user data
                $this->session->set_userdata($user_data);
              
                // Set Message
                $this->session->set_flashdata('pass_login','You are now Logged In.');
                redirect('welcome/home');
            }else{
            // Set Message
            $this->session->set_flashdata('invalid_login','Try again');
            // View
            $this->load->view('login.php');
            }

        }
    }

    public function logout(){
        // Unset User Data
        $this->session->unset_userdata('logged_in');
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        $this->session->sess_destroy();


        // Set Message
        $this->session->set_flashdata('logged_out',' <div role="alert" class="alert alert-primary alert-dismissible"> <button type="button" data-dismiss="alert" aria-label="Close" class="close"><span aria-hidden="true" class="mdi mdi-close"></span></button><span class="icon mdi mdi-info-outline"></span><strong>Info!</strong> Successfully You are Logout
                  </div>');
          //$this->load->view('login.php');
		  redirect('welcome/index');
    }

}
?>
		
		
 