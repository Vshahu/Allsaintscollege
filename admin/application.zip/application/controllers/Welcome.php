<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct(){
            parent::__construct();
            $this->load->helper(array('form','url'));
            $this->load->library(array('session', 'form_validation', 'email'));
            $this->load->library("cart");
            $this->load->database();
            $this->load->model('user');
        }
		

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('login');
	}
	
	   
	public function home()
	{
		$this->load->view('index');
	}
	public function headerslider()
	{
				$data['headerslider']=$this->user->getheaderSlider();

		$this->load->view('headerslider',$data);
	}
	public function parentlist()
	{
		$this->load->view('parentlist');
	}
	public function stafflist()
	{
		$this->load->view('stafflist');
	}
	public function studentlist()
	{
		$this->load->view('studentlist');
	}
	public function topbar()
	{
		$data['topbar']=$this->user->gettopbar();
		//var_dump($data['topbar']);

		$this->load->view('topbar',$data);
	}
	public function logomanagement()
	{
		$data['logo']=$this->user->getlogo();
		$this->load->view('logomanagement',$data);
	}
	public function headert()
	{
		$data['headert']=$this->user->getlogo();
		//var_dump($data['headert']);die();
		$this->load->view('include/header',$data);
	}
	public function collegehouses()
	{
				$data['collegehouses']=$this->user->getcollegehouses();

		$this->load->view('collegehouses',$data);
	}
	public function latestevents()
	{
		$data['latestevents']=$this->user->getcollegeevents();
		$this->load->view('latestevents',$data);
	}
	public function messagevideo()
	{
		$this->load->view('messagevideo');
	}
	public function latestnews()
	{
		$data['latestnews']=$this->user->getlatestevent();
		
		$this->load->view('latestnews',$data);
	}
	public function mission()
	{
		$data['mission']=$this->user->getmission();
		$this->load->view('mission',$data);
	}
	public function entrance()
	{
	$data['entrance']=$this->user->get_entrance();
		$this->load->view('entrance',$data);
	}
	public function menumgt()
	{
		$this->load->view('menumgt');
	}
	public function collegecalendar()
	{
		$data['calender']=$this->user->get_calender();
		$this->load->view('collegecalendar',$data);
	}
	public function accountsettings()
	{
		$this->load->view('accountsettings');
	}
	public function changepassword()
	{
		$this->load->view('changepassword');
	}
	public function save_topbar()
	{
	$mobile= $this->input->post('mobile');
	$email = $this->input->post('email');
	$fburl = $this->input->post('fburl');
	$twitterurl =  $this->input->post('twitterurl');
	
		$data = array(
			          'mobile'=>$mobile,
					  'email'=>$email,
					  'fburl'=>$fburl,
					  'twitterurl'=>$twitterurl

			         );
		  
				  $insert=$this->user->insert_topheader($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/topbar');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/topbar');
				  }
                
            
			
             redirect('welcome/topbar');         
	}
	public function save_logo()
	{
		
	$logocat= $this->input->post('logocat');
	$is_show= $this->input->post('is_show');
	$config['upload_path']   = './uploads/logo/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
//         $config['max_size']      = 100; 
//         $config['max_width']     = 1024; 
//         $config['max_height']    = 768;  
         $this->load->library('upload', $config);
         
         
			
        if ( ! $this->upload->do_upload('image')) {
            $error = array('error' => $this->upload->display_errors()); 
			var_dump($error);die();
            
         }
         else { 
           $data1 =  array('upload_data' => $this->upload->data()); 
          $loginbackdrop= $data1["upload_data"]["file_name"];
		  
		  //var_dump($loginbackdrop);die();
             	
         }
		 
		 $data = array(
			           'logocat'=>$logocat,
					   'image'=>$loginbackdrop,
					   'is_show'=>$is_show,
			          );
					   
					   $insert=$this->user->insert_logo($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/logomanagement');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/logomanagement');
				  }         
	}
		
	 public function save_headerslider(){
		 $position= $this->input->post('position');
         
		 $config['upload_path']   = './uploads/slider/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
//         $config['max_size']      = 100; 
//         $config['max_width']     = 1024; 
//         $config['max_height']    = 768;  
         $this->load->library('upload', $config);
         
         
			
        if ( ! $this->upload->do_upload('image')) {
            $error = array('error' => $this->upload->display_errors()); 
			var_dump($error);die();
            
         }
         else { 
           $data1 =  array('upload_data' => $this->upload->data()); 
          $loginbackdrop= $data1["upload_data"]["file_name"];
		  
		  //var_dump($loginbackdrop);die();
             	
         }
		 
		 $data = array(
			           'sliderOrder'=>$position,
					   'imgName'=>$loginbackdrop,
			          );
					   
					   $insert=$this->user->insert_headerslider($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/headerslider');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/headerslider');
				  }
					 
      } 
	  public function save_collegehouseslider(){
		 $position= $this->input->post('position');
         
		 $config['upload_path']   = './uploads/collegehouseslider/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
//         $config['max_size']      = 100; 
//         $config['max_width']     = 1024; 
//         $config['max_height']    = 768;  
         $this->load->library('upload', $config);
         
         
			
        if ( ! $this->upload->do_upload('image')) {
            $error = array('error' => $this->upload->display_errors()); 
			var_dump($error);die();
            
         }
         else { 
           $data1 =  array('upload_data' => $this->upload->data()); 
          $loginbackdrop= $data1["upload_data"]["file_name"];
		  
         }
		 
		 $data = array(
			           'sliderOrder'=>$position,
					   'imgName'=>$loginbackdrop,
			          );
					   
					   $insert=$this->user->insert_collegehouseslider($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/collegehouses');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/collegehouses');
				  }
					 
      } 
	  	  public function save_latesteventslider(){
		 $position= $this->input->post('position');
         
		 $config['upload_path']   = './uploads/latesteventslider/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
//         $config['max_size']      = 100; 
//         $config['max_width']     = 1024; 
//         $config['max_height']    = 768;  
         $this->load->library('upload', $config);
         
         
			
        if ( ! $this->upload->do_upload('image')) {
            $error = array('error' => $this->upload->display_errors()); 
			var_dump($error);die();
            
         }
         else { 
           $data1 =  array('upload_data' => $this->upload->data()); 
          $loginbackdrop= $data1["upload_data"]["file_name"];
		  
         }
		 
		 $data = array(
			           'sliderOrder'=>$position,
					   'imgName'=>$loginbackdrop,
			          );
					   
					   $insert=$this->user->insert_latesteventslider($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/latestevents');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/latestevents');
				  }
					 
      }
	   public function save_messagevideo(){
		 $position= $this->input->post('position');
         
		 $config['upload_path']   = './uploads/latesteventslider/'; 
         $config['allowed_types'] = 'gif|jpg|png'; 
//         $config['max_size']      = 100; 
//         $config['max_width']     = 1024; 
//         $config['max_height']    = 768;  
         $this->load->library('upload', $config);
         
         
			
        if ( ! $this->upload->do_upload('image')) {
            $error = array('error' => $this->upload->display_errors()); 
			var_dump($error);die();
            
         }
         else { 
           $data1 =  array('upload_data' => $this->upload->data()); 
          $loginbackdrop= $data1["upload_data"]["file_name"];
		  
         }
		 
		 $data = array(
			           'sliderOrder'=>$position,
					   'imgName'=>$loginbackdrop,
			          );
					   
					   $insert=$this->user->insert_latesteventslider($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/latestevents');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/latestevents');
				  }
					 
      }
	  public function save_latestnews()
	{
	$newstitle= $this->input->post('newstitle');
	$description = $this->input->post('description');
	$position = $this->input->post('position');
		
		$data = array(
			          'newstitle'=>$newstitle,
					  'description'=>$description,
					  'position'=>$position,
					  );
		  
				  $insert=$this->user->insert_latestnews($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/latestnews');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/latestnews');
				  }
                
            
			
             redirect('welcome/latestnews');         
	}
	public function save_mission()
	{
	$missiontitle= $this->input->post('missiontitle');
	$description = $this->input->post('description');
	
		
		$data = array(
			          'missiontitle'=>$missiontitle,
					  'description'=>$description,
					 
					  );
		  
				  $insert=$this->user->insert_mission($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/mission');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/mission');
				  }
                
            
			
             redirect('welcome/mission');         
	}
	public function save_entrance()
	{
	$title= $this->input->post('title');
	$description = $this->input->post('description');
	
		
		$data = array(
			          'title'=>$title,
					  'description'=>$description,
					 
					  );
		  
				  $insert=$this->user->insert_entrance($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/entrance');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/entrance');
				  }
                
            
			
             redirect('welcome/entrance');         
	}
	public function save_calender()
	{
	$eventdate= $this->input->post('eventdate');
	$eventdetails = $this->input->post('eventdetails');
	
		
		$data = array(
			          'event_date'=>$eventdate,
					  'eventdetails'=>$eventdetails,
					 
					  );
		  
				  $insert=$this->user->insert_calender($data);
				  if($insert == true)
				  {
				  $this->session->set_flashdata('success','Successfully Save');
				   redirect('welcome/collegecalendar');
				  }else{
				   $this->session->set_flashdata('error','Oop Try Again');
				    redirect('welcome/collegecalendar');
				  }
                
            
			
             redirect('welcome/entrance');         
	}
}
