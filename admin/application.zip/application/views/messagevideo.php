<?php include 'include/top.php';?>
<?php include 'include/header.php';?>
<?php include 'include/leftmenu.php';?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Principal’s  Message &amp; Vedio
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>  Principal’s  Management </a></li>
    
        <li class="active">   Principal’s  Message &amp; Vedio  </li>
      </ol>
    </section>

    <!-- Main content -->
  <section class="content">

     
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Message &amp; vedio </h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">
				 
				 <form action="<?php echo base_url('index.php/welcome/save_messagevideo');?>" method="post" enctype="multipart/form-data" class="form-horizontal">
              <div class="box-body">
               
                <div class="form-group">
                  <div class="col-sm-6 col-sm-offset-3">
                    <textarea class="form-control" placeholder="Add Principal’s  Message" id="message" name="message"></textarea> 
                  </div>
                </div>
				
                <div class="form-group mb-0-imp">
                
                  <div class="col-sm-6 col-sm-offset-3">
                     <input type="url" class="form-control" id="linkvideo" name="linkvideo" placeholder="Add Video Link">
                  </div>
                </div>
        
                <div class="form-group mb-0-imp">
                  <div class="col-sm-6 col-sm-offset-3">
                      <label class="control-label pt-0">OR</label>
                    </div>
                </div>
                <div class="form-group">
                  <div class="col-sm-6 col-sm-offset-3">
                      <label class="control-label pt-0">Upload Video</label>
                    </div>
                  <div class="col-sm-6 col-sm-offset-3">
                    <input type="file" class="form-control" id="video" name="video" title="Upload Video">
                  </div>
                </div>
				
               
                <div class="form-group">
        					<div class="col-sm-6 col-sm-offset-3">
        						<button type="submit" class="btn btn-info"><i class="fa fa-floppy-o" aria-hidden="true"></i> <strong>Update</strong></button>
        						<button type="reset" class="btn btn-default"><i class="fa fa-times" aria-hidden="true"></i> <strong>Reset</strong></button>	
        					</div>
        				</div>
              </div>
              
              
            </form>
          
			</div>
            
           
          </div>

        </div>
       
        </div>
      
	
	<div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Principal’s Message & Vedio List</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        
        
        <div class="box-footer">
          
            
            <div class="box-body">
              <table class="table table-bordered">
                <tr>
                  <th>Principal’s  Message </th>
                  <th>Video Link</th>
                  <th>Last Updated</th>
                  <th style="width: 80px">Action</th>
                </tr>
                <tr>
                  <td>Our school motto, ‘Fear of the Lord is the beginning of wisdom’ has always been a guiding light for All Saints’ College. The College has always nurtured, since time immemorial, a spirit of marching forward and keeping abreast with our ever changing society. Global thinking has always been a prime concern for all of us. Here, in All Saints’ a firm moral foundation based on Christian values of love, faith, hope, charity, grace and service is laid by each and every member of our family. We being a member school of the Church of North-India, Diocese of Agra, steadfastly believe in imparting and upholding values of Christian spirit in…</td>
                  <td>http://static.allsaintscollege.org/videoprincipals.mp4</td>
                  <td>25/03/2019</td>
                  <td>
                     <div class="btn-group">
                      
                       <button title="Deactive" type="button" class="btn btn-default btn-xs"><i class="fa fa-ban"></i></button>
                      <button title="Delete" type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash "></i></button>
                    </div>
                  </td>
                </tr>
               <tr>
                  <td>Our school motto, ‘Fear of the Lord is the beginning of wisdom’ has always been a guiding light for All Saints’ College. The College has always nurtured, since time immemorial, a spirit of marching forward and keeping abreast with our ever changing society. Global thinking has always been a prime concern for all of us. Here, in All Saints’ a firm moral foundation based on Christian values of love, faith, hope, charity, grace and service is laid by each and every member of our family. We being a member school of the Church of North-India, Diocese of Agra, steadfastly believe in imparting and upholding values of Christian spirit in…</td>
                  <td>http://static.allsaintscollege.org/videoprincipals.mp4</td>
                  <td>25/03/2019</td>
                 
                  <td>
                     <div class="btn-group">
                      <button title="Active" type="button" class="btn btn-info btn-xs"><i class="fa fa-check"></i></button>
                     
                      <button title="Delete" type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash "></i></button>
                    </div>
                  </td>
                </tr>
              </table>
            </div>
            
          
        </div>
      </div>
      

    </section>
    
  </div>
      <!-- /.content-wrapper -->
<?php include 'include/footer.php';?>
<?php include 'include/bottom.php';?>