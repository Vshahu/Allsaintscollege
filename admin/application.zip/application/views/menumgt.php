<?php include 'include/top.php';?>
<?php include 'include/header.php';?>
<?php include 'include/leftmenu.php';?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Menu MGT
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Entrance Test </a></li>
    
        <li class="active">   Mission of the school  </li>
      </ol>
    </section>

    <!-- Main content -->
  <!--  <section class="content">

     
      <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Update Logo</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">
				 
            <form class="form-horizontal">
              <div class="box-body">
               
                <div class="form-group">
                  <div class="col-sm-6 col-sm-offset-3">
                    <select required="" class="form-control">
                        <option selected="selected" disabled>Select Logo Category</option>                      
                              <option>College Logo</option>
                              <option>Brand Logo - 1</option>
                              <option>Brand Logo - 2</option>
                              <option>Brand Logo - 3</option>
                      </select>
                  </div>
                </div>
				
                <div class="form-group">
                  <div class="col-sm-6 col-sm-offset-3">
                      <label class="control-label pt-0">Upload Image</label>
                    </div>
                  <div class="col-sm-6 col-sm-offset-3">
                    <input type="file" class="form-control" id="" title="Upload Image">
                  </div>
                </div>
				
               
                <div class="form-group">
					<div class="col-sm-6 col-sm-offset-3">
						<button type="submit" class="btn btn-info"><i class="fa fa-floppy-o" aria-hidden="true"></i> <strong>Update</strong></button>
						<button type="reset" class="btn btn-default"><i class="fa fa-times" aria-hidden="true"></i> <strong>Reset</strong></button>	
					</div>
				</div>
              </div>
              
              
            </form>
          
			</div>
            
           
          </div>

        </div>
       
        </div>
      
	
	<div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Logo List</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        
        
        <div class="box-footer">
          
            
            <div class="box-body">
              <table class="table table-bordered">
                <tr>
                  <th>College Logo</th>
                  <th>Brand Logo - 1</th>
                  <th>Brand Logo - 2</th>
                  <th>Brand Logo - 3</th>
                  <th style="width: 65px">Action</th>
                </tr>
                <tr>
                  <td> <img src="img/user2-160x160.jpg" style="width: 23px;"  class="user-image" alt="Slider"></td>
                  <td> <img src="img/user2-160x160.jpg" style="width: 23px;"  class="user-image" alt="Slider"></td>
                  <td> <img src="img/user2-160x160.jpg" style="width: 23px;"  class="user-image" alt="Slider"></td>
                  <td> <img src="img/user2-160x160.jpg" style="width: 23px;"  class="user-image" alt="Slider"></td>
                  <td>
                     <div class="btn-group">
                      <button title="Delete" type="button" class="btn btn-info btn-xs"><i class="fa fa-pencil-square "></i></button>
                      <button title="Delete" type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash "></i></button>
                    </div>
                  </td>
                </tr>
               
              </table>
            </div>
            
          
        </div>
      </div>
      

    </section>-->
    
  </div>
      <!-- /.content-wrapper -->
<?php include 'include/footer.php';?>
<?php include 'include/bottom.php';?>