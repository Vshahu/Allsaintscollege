<?php 

/*
* Model
*/
class Authenticate_model extends CI_Model
{

 public function __construct()
                          {
	parent::__construct();
	}
    public function login($username, $password){
        
        // Validate
        $this->db->where('username',$username);
        $this->db->where('password',$password);

        $result = $this->db->get('user');

        if ($result->num_rows() == 1) {
            return $result->row();
        }else{
            return false;
        }
    }

}
